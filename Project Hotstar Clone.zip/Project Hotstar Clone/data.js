let movies = [
    {
        name: 'Loki',
        des: 'Loki, the God of Mischief, steps out of his brothers shadow to embark on an adventure that takes place after the events of Avengers: Endgame',
        image:'lokiSlider.png'
    },
    {
        name: 'Falcon and the winter soldier',
        des: 'Falcon and the Winter Soldier are a mismatched duo who team up for a global adventure that will test their survival skills -- as well as their patience.',
        image:'slider 2.png'
    },
    {
        name: "Wanda Vision",
        des: "Living idealized suburban lives, super-powered beings Wanda and Vision begin to suspect that everything is not as it seems.",
        image:"slider 3.png"
    },
    {
        name: 'Raya and the last dragon',
        des: 'Raya, a warrior, sets out to track down Sisu, a dragon, who transferred all her powers into a magical gem which is now scattered all over the kingdom of Kumandra, dividing its people.',
        image: 'slider 4.png'
    },
    {
        name: 'Luca',
        des: 'Set in a beautiful seaside town on the Italian Riviera, the original animated feature is a coming-of-age story about one young boy experiencing an unforgettable summer filled with gelato, pasta and endless scooter rides. Luca shares these adventures with his newfound best friend, but all the fun is threatened by a deeply held secret: he is a sea monster from another world just below the water surface.',
        image: 'slider 5.png'
    }
]
